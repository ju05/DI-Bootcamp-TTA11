from week3.day3.atm import AtmAccount



# account2 = AtmAccount('Juliana S.')
# print(account2._balance)

# print(help(AtmAccount))